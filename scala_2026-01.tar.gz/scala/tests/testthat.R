library(testthat)
library(scala)

test_check("scala")
