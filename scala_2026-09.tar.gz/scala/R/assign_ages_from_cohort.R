#' Assign ages using a cohort model
#'
#' @description Assigns ages through the shared \code{\link{assign_ages}}
#'   implementation, with model-class validation.
#' @inheritParams assign_ages
#' @param cohort_model Fitted model from \code{\link{fit_cohort_alk}}
#' @return Data frame returned by \code{\link{assign_ages}}
#' @details Assignment rules, probability validation, covariate handling and
#'   uncertainty interpretation follow \code{\link{assign_ages}}.
#' @seealso \code{\link{assign_ages}}, \code{\link{fit_cohort_alk}}
#' @export
assign_ages_from_cohort <- function(fish_data, cohort_model,
    method = c("random", "mode", "expected"), predict_missing = FALSE, seed = NULL,
    keep_probabilities = FALSE, verbose = TRUE, ...) {
  if (!inherits(cohort_model, "cohort_alk")) {
    stop("cohort_model must be a fitted cohort_alk object from fit_cohort_alk().")
  }
  assign_ages(fish_data, cohort_model, method = method,
    predict_missing = predict_missing, seed = seed,
    keep_probabilities = keep_probabilities, verbose = verbose, ...)
}